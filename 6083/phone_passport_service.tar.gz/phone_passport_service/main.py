#!/usr/bin/env python
###
### This is a demonstration web service for use with 6.083 and
### App Inventor for Android (<http://appinventor.googlelabs.com>).
### This service stores and retrieves tag-value pairs in a database
### and uses the protocol necessary to communicate with the TinyWebDB
### component of an App Inventor app.  The API includes two operations:
### StoreValue(tag, value) and GetValue(tag)

### Author: David Wolber (wolber@usfca.edu), using sample of Hal Abelson

import logging
### The calls to escape here are to guard against attacks that
### try to corrupt the web page or the data base.
### To learn why this might be necessary, see http://xkcd.com/327/
from cgi import escape
from google.appengine.ext import webapp
from google.appengine.ext.webapp.util import run_wsgi_app
from google.appengine.ext import db
from google.appengine.api import mail
from django.utils import simplejson as json
from visitedplaces import read_visited_places

class StoredData(db.Model):
  tag = db.StringProperty()
  value = db.StringProperty(multiline=True)
  date = db.DateTimeProperty(required=True, auto_now=True)


IntroMessage = '''
<table border=0>
<tr valign="top">
<td><image src="/images/customLogo.gif" width="200" hspace="10"></td>
<td>
<h3>6.083</h3>
<p />
This web service is designed to work with <a
href="http://appinventor.googlelabs.com">App Inventor
for Android</a> and the TinyWebDB component. The end-goal of this service is
to communicate with a mobile app created with App Inventor.
<p />
This page your are viewing is a manual interface to the web
service to help programmers with debugging, by letting them invoke the
service operations by hand and see what would be sent to the phone.
For, example, you can invoke the get and store operations by hand,
view the existing database entries, and also delete individual entries.

</td> </tr> </table>'''


class MainPage(webapp.RequestHandler):

  def get(self):
    write_page_header(self);
    self.response.out.write(IntroMessage)
    write_available_operations(self)
    show_stored_data(self)
    self.response.out.write('</body></html>')

########################################
### Implementing the operations
### Each operation is design to respond to the JSON request
### or to the Web form, depending on whether the fmt input to the post
### is json or html.

### Each operation is a class.  The class includes the method that
### actually does the work, followed by the methods that respond
### to post and to get.

########################################
### Implementation of GetValue

def get_value_for_tag(db, tag):
  """
  Extracted method from GetValue. Retrieves a value from the DB.

  Args:
    db the reference to the database.
    tag the tag to look up.

  Returns:
    The value associated with tag, or an empty string if no such
    value exists.

  Effects:
    Hits the database to read a value.
  """
  tag = escape(tag)
  entry = db.GqlQuery("SELECT * FROM StoredData where tag = :1", tag).get()
  if entry:
    value = entry.value
  else: value = ""
  return value

def dispatch_function(name, args):

  if name == 'get_value_for_tag':
    tag = args[0]
    return get_value_for_tag(db, tag)

  if name == 'maps_api_query_for_tag':
    tag = args[0]
    width = args[1]
    height = args[2]
    return maps_api_query_for_tag(db, tag, width, height)

  if name == 'store_value_for_tag':
    tag = args[0]
    value = args[1]
    return store_value_for_tag(db, tag, value)

  if name == 'add_place_for_tag':
    tag = args[0]
    place_to_add = args[1]
    return add_place_for_tag(db, tag, place_to_add)

  if name == 'remove_place_for_tag':
    tag = args[0]
    place_to_remove = args[1]
    return remove_place_for_tag(db, tag, place_to_remove)

  if name == 'comment_place_for_tag':
    tag = args[0]
    place_to_comment = args[1]
    comment = ' '.join(args[2:])
    return comment_place_for_tag(db, tag, place_to_comment, comment)

  if name == 'readable_data_for_tag':
    tag = args[0]
    return readable_data_for_tag(db, tag)

  if name == 'share_passport':
    tag = args[0]
    receiver = args[1]
    return share_passport(db, tag, receiver)

  return 'Invoked unknown function %s with args %s' % (name, args)

class RemoteFunctionCaller(webapp.RequestHandler):
  def dispatch_function(self, name):
    """
    name should be of the format function_name arg1 arg2 ... argN
    """
    name_words = name.split(' ')
    return dispatch_function(name_words[0], name_words[1:])

  def post(self):
    to_call = self.request.get('tag')
    result = self.dispatch_function(to_call)
    if self.request.get('fmt') == 'html':
      result = escape(result[0])
      to_call = escape(to_call)
    WritePhoneOrWeb( \
        self, lambda: json.dump(['REMOTE_CALL', to_call, result], self.response.out))

  def get(self):
    self.response.out.write('''
    <html><body>
    <form action="/getvalue" method="post"
          enctype=application/x-www-form-urlencoded>
       <p>To Call<input type="text" name="tag" /></p>
       <input type="hidden" name="fmt" value="html">
       <input type="submit" value="Get value">
    </form></body></html>\n''')


########################################    
### Here's the implementation of StoreValue

def store_value_for_tag(db, tag, value):
  """
  Extracted method to store a value.

  Args:
    db a reference to the database.
    tag the tag for the value.
    value the value to store.

  Effects:
    Updates the DB with a new value.
  """
  tag = escape(tag)
  value = escape(value)
  # There's a potential readers/writers error here :(
  entry = db.GqlQuery("SELECT * FROM StoredData where tag = :1", tag).get()
  if entry:
    entry.value = value
  else: entry = StoredData(tag = tag, value = value)
  entry.put()
  return []

class StoreAValue(webapp.RequestHandler):

  def store_a_value(self, tag, value):
    store_value_for_tag(db, tag, value)
    ## Send back a confirmation message.  The TinyWebDB component ignores
    ## the message (other than to note that it was received), but other
    ## components might use this.
    result = ["STORED", tag, value]
    WritePhoneOrWeb(self, lambda : json.dump(result, self.response.out))

  def post(self):
    tag = self.request.get('tag')
    value = self.request.get('value')
    self.store_a_value(tag, value)

  def get(self):
    self.response.out.write('''
    <html><body>
    <form action="/storeavalue" method="post"
          enctype=application/x-www-form-urlencoded>
       <p>Tag<input type="text" name="tag" /></p>
       <p>Value<input type="text" name="value" /></p>
       <input type="hidden" name="fmt" value="html">
       <input type="submit" value="Store a value">
    </form></body></html>\n''')

def share_passport(db, tag, receiver):
  place_data = get_value_for_tag(db, tag)
  place_object = read_visited_places(place_data)
  sender = 'rahulrajago@gmail.com'
  subject = '%s is sharing his Phone Passport with you' % (tag)
  map_link = maps_api_query_for_tag(db, tag, 1000, 1000)[0]
  body = """
  
  Hi,

  %s has shared a copy of his/her Phone Passport with you.

  Here's a link to his/her map:
  %s

  Here's %s's comments:
  %s

  Interested? Download Phone Passport, and let your friends know
  how well-traveled you are!
  """ % (tag, map_link, tag, place_object.as_human_readable_string())
  mail.send_mail(sender=sender, to=receiver,
      subject=subject,
      body=body)
  return [place_object.as_human_readable_string()]

def readable_data_for_tag(db, tag):
  place_value = get_value_for_tag(db, tag)
  place_object = read_visited_places(place_value)
  return [place_object.as_human_readable_string()]

def comment_place_for_tag(db, tag, place_to_comment, comment):
  def comment_place_transformer(old_value):
    places = read_visited_places(old_value)
    return places.add_comment_to_place(place_to_comment,
        comment).as_database_string()
  update_value_for_tag(db, tag, comment_place_transformer)
  return [place_to_comment]

def add_place_for_tag(db, tag, place_to_add):
  def add_place_transformer(old_value):
    places = read_visited_places(old_value)
    return places.add_place(place_to_add).as_database_string()
  update_value_for_tag(db, tag, add_place_transformer)
  return [place_to_add]

def remove_place_for_tag(db, tag, place_to_remove):
  def remove_place_transformer(old_value):
    places = read_visited_places(old_value)
    return places.remove_place(place_to_remove).as_database_string()
  update_value_for_tag(db, tag, remove_place_transformer)
  return [place_to_remove]


def update_value_for_tag(db, tag, value_transformer):
  """
  Helper function to update a value in the database.

  Args:
    db a reference to the database.
    tag the tag to look up for the value.
    value_transformer the function to apply to the value. Should take
                      a Str)ng and return a String.

  Effects:
    Reads the value for tag from the DB, applies value_transformer
    to it, then stores the new value into the DB under tag.
  """
  value = get_value_for_tag(db, tag)
  new_value = value_transformer(value)
  store_value_for_tag(db, tag, new_value) 


def maps_api_query_for_tag(db, tag, width, height):
  """
  Given a tag, looks up the place string for that tag, and puts
  it into a Google Static Maps API query string that can be
  sent out to retrieve a map.

  Args:
    db a reference to the database
    tag the tag to look up
    width the width of the map
    height the height of the map
  """

  base_url = 'http://maps.googleapis.com/maps/api/staticmap?'
  zoom_level = '1'
  map_type = 'roadmap'

  value = get_value_for_tag(db, tag)
  marker_locations = read_visited_places(value).as_marker_locations()

  api_query = '%szoom=%s&size=%sx%s&maptype=%s&markers=%s&sensor=false' % \
      (base_url, zoom_level, width, height, map_type, marker_locations)
  return [api_query]


### The DeleteEntry is called from the Web only, by pressing one of the
### buttons on the main page.  So there's no get method, only a post.

class DeleteEntry(webapp.RequestHandler):

  def post(self):
    logging.debug('/deleteentry?%s\n|%s|' %
                  (self.request.query_string, self.request.body))
    entry_key_string = self.request.get('entry_key_string')
    key = db.Key(entry_key_string)
    tag = self.request.get('tag')
    db.run_in_transaction(dbSafeDelete,key)
    self.redirect('/')


########################################
#### Procedures used in displaying the main page

### Show the API
def write_available_operations(self):
  self.response.out.write('''
    <p>Available calls:\n
    <ul>
    <li><a href="/storeavalue">/storeavalue</a> Store a value</li>
    <li><a href="/getvalue">/getvalue</a>: Call a remote function</li>
    </ul>''')

### Generate the page header
def write_page_header(self):
  self.response.headers['Content-Type'] = 'text/html'
  self.response.out.write('''
     <html>
     <head>
     <style type="text/css">
        body {margin-left: 5% ; margin-right: 5%; margin-top: 0.5in;
             font-family: verdana, arial,"trebuchet ms", helvetica, sans-serif;}
        ul {list-style: disc;}
     </style>
     <title>Tiny WebDB</title>
     </head>
     <body>''')
  self.response.out.write('<h2>App Inventor for Android: Custom Tiny WebDB Service</h2>')

### Show the tags and values as a table.
def show_stored_data(self):
  self.response.out.write('''
    <p><table border=1>
      <tr>
         <th>Key</th>
         <th>Value</th>
         <th>Created (GMT)</th>
      </tr>''')
  entries = StoredData.all().order("-tag")
  for e in entries:
    entry_key_string = str(e.key())
    self.response.out.write('<tr>')
    self.response.out.write('<td>%s</td>' % escape(e.tag))
    self.response.out.write('<td>%s</td>' % escape(e.value))      
    self.response.out.write('<td><font size="-1">%s</font></td>\n' % e.date.ctime())
    self.response.out.write('''
      <td><form action="/deleteentry" method="post"
            enctype=application/x-www-form-urlencoded>
	    <input type="hidden" name="entry_key_string" value="%s">
	    <input type="hidden" name="tag" value="%s">
            <input type="hidden" name="fmt" value="html">
	    <input type="submit" style="background-color: red" value="Delete"></form></td>\n''' %
                            (entry_key_string, escape(e.tag)))
    self.response.out.write('</tr>')
  self.response.out.write('</table>')


#### Utilty procedures for generating the output

#### Write response to the phone or to the Web depending on fmt
#### Handler is an appengine request handler.  writer is a thunk
#### (i.e. a procedure of no arguments) that does the write when invoked.
def WritePhoneOrWeb(handler, writer):
  if handler.request.get('fmt') == "html":
    WritePhoneOrWebToWeb(handler, writer)
  else:
    handler.response.headers['Content-Type'] = 'application/jsonrequest'
    writer()

#### Result when writing to the Web
def WritePhoneOrWebToWeb(handler, writer):
  handler.response.headers['Content-Type'] = 'text/html'
  handler.response.out.write('<html><body>')
  handler.response.out.write('''
  <em>The server will send this to the component:</em>
  <p />''')
  writer()
  WriteWebFooter(handler, writer)


#### Write to the Web (without checking fmt)
def WriteToWeb(handler, writer):
  handler.response.headers['Content-Type'] = 'text/html'
  handler.response.out.write('<html><body>')
  writer()
  WriteWebFooter(handler, writer)

def WriteWebFooter(handler, writer):
  handler.response.out.write('''
  <p><a href="/">
  <i>Return to Application Main Page</i>
  </a>''')
  handler.response.out.write('</body></html>')

### A utility that guards against attempts to delete a non-existent object
def dbSafeDelete(key):
  if db.get(key) :  db.delete(key)


### Assign the classes to the URL's

application =     \
   webapp.WSGIApplication([('/', MainPage),
                           ('/storeavalue', StoreAValue),
                           ('/getvalue', RemoteFunctionCaller),
                           ],
                          debug=True)

def main():
  run_wsgi_app(application)

if __name__ == '__main__':
  main()

### Copyright 2009 Google Inc.
###
### Licensed under the Apache License, Version 2.0 (the "License");
### you may not use this file except in compliance with the License.
### You may obtain a copy of the License at
###
###     http://www.apache.org/licenses/LICENSE-2.0
###
### Unless required by applicable law or agreed to in writing, software
### distributed under the License is distributed on an "AS IS" BASIS,
### WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
### See the License for the specific language governing permissions and
### limitations under the License.
###
