from inject import assign_injectables
import copy

class Place(object):
  """
  Immutable data object linking a place with the comment a person made about it.
  """
  def __init__(self, place, comment=None):
    assign_injectables(self, locals())

  def get_place(self):
    return self.place

  def get_comment(self):
    return self.comment

  def as_database_string(self):
    """
    Returns self, fomatted as part of a database string.
    """
    if self.comment is not None:
      return "%s : %s" % (self.place, self.comment)
    else:
      return self.place

  def as_human_readable_string(self):
    """
    Format as a human-readable string.
    """
    if self.comment is not None:
      formatted_comment = self.comment.replace('+', ' ')
    else:
      formatted_comment = 'No comment'
    return "%s: %s" % (self.place, formatted_comment)

class VisitedPlaces(object):
  """
  Immutable data object to show the various places that a person has visited.
  """
  def __init__(self, visited_places):
    """
    Constructor for VisitedPlaces

    Args:
      visited_places a list of Places representing places to mark on a map.
    """
    assign_injectables(self, locals())

  def has_place(self, place):
    """
    For testing, report if place is in self.visited_places 

    Args:
      place the place to test

    Returns:
      True if place is in self.visited_places
    """
    place_names = [visited.get_place() for visited in self.visited_places]
    return place in place_names

  def is_empty(self):
    """
    For testing, report if self.visited_places is empty.

    Returns:
      True if self.visited_places is an empty list.
    """
    return len(self.visited_places) == 0

  def add_place(self, new_place):
    """
    Add a new place, resulting in a VisitedPlaces with the new place included.
    Does not mutate in-place, creates a new object instead.

    Args:
      new_place the name of the place to add.

    Returns:
      A new VisitedPlaces with the updated set of places.
    """
    places_copy = copy.copy(self.visited_places)
    places_copy.append(Place(new_place))
    return VisitedPlaces(places_copy)

  def get_comment_for_place(self, place):
    """ Searches for place, and returns its comment. """
    match = [visited for visited in self.visited_places \
        if visited.get_place() == place][0]
    return match.get_comment()

  def add_place_with_comment(self, new_place, comment):
    """
    Adds a new place plus a comment on it.
    """
    places_copy = copy.copy(self.visited_places)
    places_copy.append(Place(new_place, comment))
    return VisitedPlaces(places_copy)

  def add_comment_to_place(self, place, comment):
    """
    Resets the comment associated with place to the given comment.
    """
    formatted_comment = comment.strip().replace(' ', '+')
    def process_place(one_place):
      if one_place.get_place() == place:
        return Place(place, formatted_comment)
      else:
        return one_place
    new_places = map(process_place, self.visited_places)
    return VisitedPlaces(new_places)

  def remove_place(self, to_remove):
    """
    Removes a place, resulting in a VisitedPlaces without it.
    Does not mutate in-place, creates a new object instead.

    Args:
      to_remove the name of the place to remove.

    Returns:
      A new VisitedPlaces with the updated set of places.
    """
    filtered_places = [place for place in self.visited_places \
        if place.get_place() != to_remove]
    return VisitedPlaces(filtered_places)

  def as_marker_locations(self):
    """
    Convert to a string that can be embedded into a Google static maps query.

    Returns:
      A pipe-separated string containing the entries in self.visited_places.
    """
    place_names = [visited.get_place() for visited in self.visited_places]
    return '|'.join(place_names)

  def as_database_string(self):
    """
    Convert to a string that can be stored in the TinyWebDB
    """
    places_as_strings = [place.as_database_string() \
        for place in self.visited_places]
    return '|'.join(places_as_strings)

  def as_human_readable_string(self):
    """
    Convert to a string that can be displayed to the user.
    """
    places_as_readable_strings = [place.as_human_readable_string() \
        for place in self.visited_places]
    return '\n'.join(places_as_readable_strings)

def read_place_with_comment(place_with_comment_string):
  if ':' in place_with_comment_string:
    splitted = place_with_comment_string.split(':')
    stripped = [word.strip(' +') for word in splitted]
    return Place(stripped[0], stripped[1])
  else:
    return Place(place_with_comment_string.strip())

def read_visited_places(visited_places_string):
  """
  Given a pipe-separated string of visited places, converts it to a VisitedPlaces.

  Args:
    visited_places_string a string  representation of visited places, from the database.

  Returns:
    A VisitedPlaces object created from parsing the string.
  """
  splitted = visited_places_string.split('|')
  stripped = [string.strip() for string in splitted]
  no_spaces = [string.replace(' ', '+') for string in stripped]
  no_blank_strings = [string for string in no_spaces if string != '']
  places = map(read_place_with_comment, no_blank_strings)
  return VisitedPlaces(places)
