import unittest
from visitedplaces import read_visited_places

class ReadVisitedPlacesTest(unittest.TestCase):
  def test_it_should_parse_a_valid_pipe_delimited_string(self):
    place_string = 'Baltimore|Washington|Boston'
    visited = read_visited_places(place_string)
    self.assertTrue(visited.has_place('Baltimore'))
    self.assertTrue(visited.has_place('Washington'))
    self.assertTrue(visited.has_place('Boston'))

  def test_it_should_parse_a_blank_string_as_an_empty_place_list(self):
    place_string = ''
    visited = read_visited_places(place_string)
    self.assertTrue(visited.is_empty())

  def test_it_should_parse_a_single_place_as_a_singleton_list(self):
    place_string = 'Boston'
    visited = read_visited_places(place_string)
    self.assertTrue(visited.has_place('Boston'))

  def test_with_multiple_cities(self):
    place_string = 'Baltimore|Boston|Montreal|London'
    visited = read_visited_places(place_string)
    self.assertTrue(visited.has_place('Baltimore'))
    self.assertTrue(visited.has_place('Montreal'))
    self.assertTrue(visited.has_place('Boston'))
    self.assertTrue(visited.has_place('London'))

  def test_it_should_parse_comments(self):
    place_string = \
        'Baltimore:Hometown of the Orioles|Boston: Hometown of the Red Sox'
    visited = read_visited_places(place_string)
    self.assertTrue(visited.has_place('Baltimore'))
    self.assertTrue(visited.has_place('Boston'))
    self.assertEquals('Hometown+of+the+Orioles',
        visited.get_comment_for_place('Baltimore'))
    self.assertEquals('Hometown+of+the+Red+Sox',
        visited.get_comment_for_place('Boston'))

  def test_it_should_be_able_to_add_comments(self):
    place_string = 'Baltimore|Boston'
    visited = read_visited_places(place_string)
    commented = visited.add_comment_to_place('Boston', 'Hometown of the Red Sox')
    self.assertEquals('Hometown+of+the+Red+Sox',
        commented.get_comment_for_place('Boston'))
